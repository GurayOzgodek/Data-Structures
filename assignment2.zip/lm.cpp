/* @Author
* Student Name: <Bahadır Güray Özgödek>
* Student ID : <150150013>
* Date: <8.11.2018> */
#include "functions.h"

int main(int argc , char ** argv){
    language_model newModel ;
    newModel.readData(argv[1]);
    if(!argv[2]){
        newModel.vocabularylist->print();
    }
    else{
        if(argv[2][0] == '<'){                                                 // command line argument kısmında boşluk yerin <SP> 
            cout<<newModel.calculateProbability(' ' , argv[2][5]);             //ihtimaline karşılık alınan önlemler
        }
        else if(argv[2][2] == '<'){
            cout<<newModel.calculateProbability(argv[2][0] , ' ');
        }
        else if(argv[2][0] == '<' && argv[2][5] == '<'){                            
            cout<<newModel.calculateProbability(' ' , ' ');
        }
        else{
        cout<<newModel.calculateProbability(argv[2][0] , argv[2][2]);
        }
    }
}