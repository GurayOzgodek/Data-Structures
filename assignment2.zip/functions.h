/* @Author
* Student Name: <Bahadır Güray Özgödek>
* Student ID : <150150013>
* Date: <8.11.2018> */
#ifndef funtions_h
#define funtions_h
#include "vocab.h"
#include <iostream>
#include <fstream>
using namespace std;

void vocab_list::add_char(char c){
    vocab_node *newNode = new vocab_node;
    newNode->character=c;
    newNode->list=new occur_node;
    newNode->next = NULL;

    if(!head){
        head = newNode;
        tail=newNode;
    }
    else{
        traverse = head;
        if(int(newNode->character)<64){    
            if(int(newNode->character)>31){ //noktalama işaretleri ascii tablosunda bu aralıktadır.
                while(traverse){ 
                    if(traverse->character == newNode->character){
                        traverse = NULL;  // aynı karakterleri listeye koymamak için
                    }
                    else{
                        if(!traverse->next){
                            tail->next=newNode;
                            tail=newNode;
                            traverse=NULL;
                        }
                        else{
                            traverse = traverse->next;
                        }
                        
                    }
                }

            }
            else{   // \t \n \r gibi işaretleri yok saymak için 
                traverse=NULL;
            }    
        }
        while(traverse){
            if(newNode->character < traverse->character){
                head = newNode;
                newNode->next = traverse;
                traverse = NULL; 
            }
            else if(newNode->character > traverse->character){
                if(!traverse->next){
                    traverse->next = newNode;
                    tail=newNode;
                    traverse = NULL;
                }
                else{
                    if(int(traverse->next->character)<64 || newNode->character < traverse->next->character ){ //harfi noktalama işaretinden
                        newNode->next = traverse->next;                                                       //önceye almak için 
                        traverse->next = newNode;
                        traverse = NULL;
                    }
                    else{
                        traverse = traverse->next;
                    }
                }
            }
            else{
                traverse=NULL;
            }
        }
    }  
}

void vocab_list::add_occurence (char x , char y){

    occur_node *newNode = new occur_node;
    newNode->character = y;
    newNode->next = NULL;
    traverse=head;
    while(traverse){
        if(traverse->character == x){
            occur_traverse = traverse->list;
            while(occur_traverse){
                
                if(!occur_traverse->next){
                    occur_traverse->next = newNode;
                    occur_traverse = NULL;
                }
                else{
                    occur_traverse = occur_traverse->next;
                    if(newNode->character == occur_traverse->character){
                        occur_traverse->occurence++;
                        occur_traverse = NULL;
                    }
                }
            }
            traverse = NULL;
        }
        else{
            traverse = traverse->next;
        }
    }
}

void language_model::readData (const char *myFile){
    
    ifstream file (myFile);
    vocabularylist = new vocab_list;
    vocabularylist->create();
    char * letters = new char[1000];
    int i=0;
    char karakter;
    while(file.get(karakter)){
        if(int(karakter) >= 65 && int(karakter) <= 90){   
            vocabularylist->add_char(char(int(karakter)+32));  // büyük harf gelirse küçük harfe çeviriyor.
            letters[i]=char(int(karakter)+32);
            i++;
        }
        else{
            vocabularylist->add_char(karakter);
            letters[i]=karakter;
            i++;
        }
    }
    for(int a=0;letters[a]!='\0';a++){
        if(letters[a+1] == 13){ // new line karakteri gelirse boşluk bağlamak için
            vocabularylist->add_occurence(letters[a] , ' ');
            a += 1;
        }
        else if(letters[a+1] == '\0'){ //end of file karakteri gelirse boşluk bağlamak için
            vocabularylist->add_occurence(letters[a] , ' ');
        }
        else{
            vocabularylist->add_occurence(letters[a],letters[a+1]);
        }
        
    }
    delete [] letters;
    file.close();
}
void vocab_list::create(){
    head=NULL;
}

void vocab_list::print(){
    traverse = head;
    while(traverse){
        if(traverse->character == ' '){
            cout<<"<SP>"<<":"<<"\n";
        }
        else{
            cout<<traverse->character<<":"<<"\n";
        }
        
        occur_traverse = traverse->list->next;
        while(occur_traverse){
            if(occur_traverse->character == ' '){
                cout<<"\t"<<"<"<<"<SP>"<<","<<occur_traverse->occurence<<">"<<endl;
            }
            else{
                cout<<"\t"<<"<"<<occur_traverse->character<<","<<occur_traverse->occurence<<">"<<endl;
            }
            
            occur_traverse = occur_traverse->next;
        }
        traverse = traverse->next;
    }    
}

int vocab_list::get_occurence(char c){
    int total=0;
    traverse = head;
    while(traverse->character != c){
        traverse = traverse->next;
        if(traverse == NULL){ // eğer verilen karakter vocab node'da yoksa ihtimal 0 çıksın diye
            return 0;
        }
    }
    occur_traverse = traverse->list->next;

    while(occur_traverse){
        total += occur_traverse->occurence;
        occur_traverse = occur_traverse->next;
    }
    return total;
}

int vocab_list::get_union_occurence(char x, char y){
    traverse = head;
    while(traverse->character != x){
        traverse = traverse->next;
        if(traverse == NULL){ 
            return 0;
        }
    }
    occur_traverse = traverse->list->next;
    while(occur_traverse->character != y){
        occur_traverse = occur_traverse->next;
        if(occur_traverse == NULL){ 
            return 0;
        }
    }
    return occur_traverse->occurence;
}

double language_model::calculateProbability(char x , char y){
    int occurence = vocabularylist->get_occurence(x);
    int union_occurence = vocabularylist->get_union_occurence(x , y);
    if(occurence == 0){ //sayı / 0 hatasını önlemek için 
        return 0;
    }
    else{
        return double(union_occurence) / double(occurence);
    }
   
}

#endif