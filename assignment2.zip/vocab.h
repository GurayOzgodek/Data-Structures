/* @Author
* Student Name: <Bahadır Güray Özgödek>
* Student ID : <150150013>
* Date: <8.11.2018> */
#ifndef vocab_h
#define vocab_h

struct occur_node {

    char character;
    occur_node *next;
    int occurence=1;
};

struct vocab_node {
    char character;
    vocab_node *next;
    occur_node *list;
    
};

struct vocab_list{

vocab_node *head;
vocab_node *tail;
vocab_node *traverse;
occur_node *occur_traverse;
    void create();
    void print();
    void add_char(char );
    void add_occurence(char , char );
    int get_occurence(char );
    int get_union_occurence (char , char );
};

struct language_model {

vocab_list *vocabularylist ;
    void readData (const char *);
    double calculateProbability (char, char);
};

#endif